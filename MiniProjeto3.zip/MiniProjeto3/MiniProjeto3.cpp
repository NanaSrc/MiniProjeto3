// Realizado por: Anna Garcia
// 29-06-2022
// MiniProjeto3

#include <iostream>
#include <conio.h>
#include <string>
using namespace std;

const int TAMDEFAULT = 12; // Constante que define o tamanho default da célula da tabela de listagem (questão estética)
bool inicializado = false;
string fichas[21][5];

void Menu()
{
    system("cls");
    system("title Menu");
    cout << "\t-----------------------/ M E N U /-----------------------\n"
        << "\t[A] - Inicializar\n"
        << "\t[B] - Listar\n"
        << "\t[C] - Inserir nova ficha\n"
        << "\t[D] - Mais velho da lista\n"
        << "\t[E] - Numero de raparigas\n"
        << "\t[F] - Numero de rapazes em Maximinos\n"
        << "\t[G] - Ano repetido\n"
        << "\t[H] - Verificar se ha anos repetidos\n"
        << "\t[I] - Lista de raparigas\n"
        << "\t[J] - Localizar e trocar um nome\n"
        << "\t[ESC] - Sair\n\n"
        << "\t>> ";
}

void Inicializar()
{
    fichas[1][1] = "Ana";
    fichas[2][1] = "Bela";
    fichas[3][1] = "Carlos";
    fichas[4][1] = "Carlota";
    fichas[5][1] = "Daniel";
    fichas[6][1] = "Diogo";
    fichas[7][1] = "Elvira";
    fichas[8][1] = "Fernanda";
    fichas[9][1] = "Fernando";
    fichas[10][1] = "Gilherme";
    fichas[11][1] = "Hilda";
    fichas[12][1] = "Josildo";
    fichas[13][1] = "Josecas";
    fichas[14][1] = "Maria";
    fichas[15][1] = "Anabela";
    fichas[16][1] = "Otaviano";
    fichas[17][1] = "Rui";
    fichas[18][1] = "Silvério";
    fichas[19][1] = "Teodoro";
    fichas[20][1] = "Zacarias";

    fichas[1][2] = "Maximinos";
    fichas[2][2] = "Gualtar";
    fichas[3][2] = "Lomar";
    fichas[4][2] = "Lomar";
    fichas[5][2] = "Cividade";
    fichas[6][2] = "Lamaceiros";
    fichas[7][2] = "Maximinos";
    fichas[8][2] = "Ferreiros";
    fichas[9][2] = "Maximinos";
    fichas[10][2] = "Cividade";
    fichas[11][2] = "Cabreira";
    fichas[12][2] = "Cividade";
    fichas[13][2] = "Gualtar";
    fichas[14][2] = "Cividade";
    fichas[15][2] = "Gualtar";
    fichas[16][2] = "Maximinos";
    fichas[17][2] = "Maximinos";
    fichas[18][2] = "Maximinos";
    fichas[19][2] = "Gualtar";
    fichas[20][2] = "Lindoso";

    fichas[1][3] = "F"; fichas[1][4] = "1980";
    fichas[2][3] = "F"; fichas[2][4] = "1982";
    fichas[3][3] = "M"; fichas[3][4] = "1981";
    fichas[4][3] = "M"; fichas[4][4] = "1980";
    fichas[5][3] = "M"; fichas[5][4] = "1980";
    fichas[6][3] = "M"; fichas[6][4] = "1980";
    fichas[7][3] = "F"; fichas[7][4] = "1977";
    fichas[8][3] = "F"; fichas[8][4] = "1977";
    fichas[9][3] = "M"; fichas[9][4] = "1983";
    fichas[10][3] = "M"; fichas[10][4] = "1989";
    fichas[11][3] = "F"; fichas[11][4] = "1980";
    fichas[12][3] = "M"; fichas[12][4] = "1981";
    fichas[13][3] = "M"; fichas[13][4] = "1982";
    fichas[14][3] = "F"; fichas[14][4] = "1975";
    fichas[15][3] = "F"; fichas[15][4] = "1980";
    fichas[16][3] = "M"; fichas[16][4] = "1988";
    fichas[17][3] = "M"; fichas[17][4] = "1987";
    fichas[18][3] = "M"; fichas[18][4] = "1980";
    fichas[19][3] = "M"; fichas[19][4] = "1985";
    fichas[20][3] = "M"; fichas[20][4] = "1986";
}

void Listar()
{
    // Variáveis da função
    int espacos = 0;
    cout << " Indice     | Nome      | Freguesia    | Sexo   | Nascimento  "
        << "\n------------------------------------------------------------\n"; // Construção da tabela

    for (int i = 1; i < 21; i++) // Adiciona índice à tabela
    {
        if (i < 10) // Alinha os números adicionando um zero à esquerda caso o número tenha apenas uma casa decimal
            cout << " [ 0" << i << " ]      ";
        else
            cout << " [ " << i << " ]      ";

        for (int j = 1; j < 5; j++) // Escreve os dados da lista na tabela
        {
            if (j == 4) // Quebra de linha caso seja o último item da linha (significa novo registo)
                cout << fichas[i][j] << "\n";
            else if (j == 3) // Alinhar margem do sexo (questão estética)
            {
                cout << "    " << fichas[i][j] << "        ";
            }
            else // Alinha as palavras de forma a ficar visualmente fácil de ler
            {
                espacos = TAMDEFAULT - fichas[i][j].length();
                cout << fichas[i][j];

                for (int i = 0; i < espacos; i++)
                {
                    cout << " ";
                }
            }
        }
    }
}

void NovaFicha(int pos, string nome, string freguesia, string sexo, string ano)
{
    try
    {
        fichas[pos][1] = nome;
        fichas[pos][2] = freguesia;
        fichas[pos][3] = sexo;
        fichas[pos][4] = ano;

        system("cls");
        cout << "Nova ficha adicionada com sucesso!\n";
        inicializado = true;
    }
    catch (exception)
    {
        system("cls");
        cout << "Dados invalidos.\n";
    }
    system("pause");
}

int QuantRaparigas()
{
    int contador = 0;

    for (int i = 1; i < 21; i++)
    {
        if (fichas[i][3] == "F")
            contador++;
    }

    return contador;
}

int QuantRapazesMaximinos()
{
    int contador = 0;

    for (int i = 1; i < 21; i++)
    {
        if (fichas[i][3] == "M" && fichas[i][2] == "Maximinos")
            contador++;
    }

    return contador;
}

bool Repetido(string ano)
{
    int contador = 0;

    for (int i = 1; i < 21; i++)
    {
        if (fichas[i][4] == ano)
            contador++;
    }

    if (contador > 1)
        return true;
    else
        return false;
}

string MaisVelho()
{
    // Variáveis da função
    int maiorIdade = 0, posMaior;
    try
    {
        for (int i = 1; i < 21; i++)
        {
            /*if (fichas[1][4].empty())
                fichas[1][4] = '0';*/

            if ((2021 - stoi(fichas[i][4])) > maiorIdade) // Compara a idade 
            {
                maiorIdade = 2021 - stoi(fichas[i][4]);
                posMaior = i;
            }
        }
        return fichas[posMaior][1]; // Retorna o nome do maior
    }
    catch (exception)
    {
        return "#@?";
    }
    
}

void ListarRaparigas()
{
    int espacos = 0;
    cout << " Indice     | Nome      | Freguesia    | Sexo   | Nascimento  "
        << "\n------------------------------------------------------------\n"; 

    for (int i = 1; i < 21; i++) 
    {
        if (fichas[i][3] == "F")
        {
            if (i < 10) 
                cout << " [ 0" << i << " ]      ";
            else
                cout << " [ " << i << " ]      ";

            for (int j = 1; j < 5; j++) 
            {
                if (j == 4) 
                    cout << fichas[i][j] << "\n";
                else if (j == 3) 
                {
                    cout << "    " << fichas[i][j] << "        ";
                }
                else 
                {
                    espacos = TAMDEFAULT - fichas[i][j].length();
                    cout << fichas[i][j];

                    for (int i = 0; i < espacos; i++)
                    {
                        cout << " ";
                    }
                }
            }
        }
    }
}

bool HaAnosRepetidos()
{
    bool repetido = false;

    for (int i = 1; i < 21; i++)
    {
        for (int j = i + 1; j < 21; j++)
        {
            if (fichas[i][4] == fichas[j][4])
            {
                repetido = true;
                i = 21;
            }
        }
    }
    if (repetido)
        return true;
    else
        return false;
}

int main()
{
    char op;
    int pos;
    string nome, freguesia, sexo, ano;

    do
    {
        Menu();
        op = _getch();

        switch (op)
        {
            case 'A': // Inicializar
            case 'a':
                inicializado = true;
                system("cls");
                system("title Inicializar");
                Inicializar();
                cout << "Lista inicializada com sucesso.\n";
                system("pause");
                break;

            case 'B': // Listar
            case 'b':
                system("cls");
                system("title Listar");
                Listar();
                system("pause");
                break;

            case 'C': // Nova ficha
            case 'c':
                system("cls");
                system("title Nova ficha");

                cout << "Insira a posicao da ficha: ";
                cin >> pos;
                cout << "Nome: ";
                cin >> nome;
                cout << "Freguesia: ";
                cin >> freguesia;
                cout << "Sexo: ";
                cin >> sexo;
                cout << "Ano de nascimento: ";
                cin >> ano;
                NovaFicha(pos, nome, freguesia, sexo, ano);
                break;

            case 'D': // Mais velho
            case 'd':
                if (inicializado)
                {
                    system("cls");
                    system("title Mais velho");

                    if (MaisVelho() != "#@?")
                    {
                        cout << "Atualmente o mais velho da lista e " << MaisVelho() << "\n";
                    }
                    else
                    {
                        cout << "Nao foi encontrado um registo valido.\n";
                    }
                    system("pause");
                }
                else
                {
                    cout << "\n\tERROR: A lista ainda nao possui registos.\n\n\t";
                    system("pause");
                }
                break;

            case 'E': // Número de raparigas
            case 'e':
                if (inicializado)
                {
                    system("cls");
                    system("title Numero de raparigas");
                    cout << "Existem um total de " << QuantRaparigas() << " raparigas na lista.\n";
                }
                else 
                {
                    cout << "\n\tERROR: A lista ainda nao possui registos.\n\n\t";
                }
                system("pause");
                break;

            case 'F': // Número de rapazes em maximinos
            case 'f':
                if (inicializado)
                {
                    system("cls");
                    system("title Numero de rapazes em maximinos");
                    cout << "Existem um total de " << QuantRapazesMaximinos() << " rapazes em Maximinos.\n";
                }
                else
                {
                    cout << "\n\tERROR: A lista ainda nao possui registos.\n\n\t";
                }
                system("pause");
                break;

            case 'G': // Ano repetido
            case 'g':
                if (inicializado)
                {
                    system("cls");
                    system("title Esse ano aparece repetido?");
                    cout << "Insira um ano: ";
                    cin >> ano;
                    system("cls");

                    if (Repetido(ano))
                        cout << "Sim, este ano aparece repetido na lista\n";
                    else
                        cout << "Nao, este ano nao aparece repetido na lista.\n";
                }
                else
                {
                    cout << "\n\tERROR: A lista ainda nao possui registos.\n\n\t";
                }
                system("pause");
                break;

            case 'H': // Há anos repetidos
            case 'h':
                if (inicializado)
                {
                    system("cls");
                    system("title Existem anos repetidos?");
                    if (HaAnosRepetidos())
                        cout << "Sim, existem anos repetidos.\n";
                    else
                        cout << "Nao, nao existem anos repetidos.\n";
                }
                else
                {
                    cout << "\nERROR: A lista ainda nao possui registos.\n\n\t";
                }

                system("pause");
                break;

            case 'I': // Listar raparigas
            case 'i':
                system("cls");
                system("title Lista de raparigas");
                ListarRaparigas();
                system("pause");
                break;

            case 'J': // Localizar e trocar um nome
            case 'j':
                system("cls");
                system("title Localizar e trocar um nome");
                system("pause");
                break;

            default:
                break;
        }

    } while (op != 27);
}

